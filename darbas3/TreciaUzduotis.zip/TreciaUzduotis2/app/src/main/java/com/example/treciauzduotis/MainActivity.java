package com.example.treciauzduotis;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.pes.androidmaterialcolorpickerdialog.ColorPicker;
import com.pes.androidmaterialcolorpickerdialog.ColorPickerCallback;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int CAMERA_REQUEST = 1888;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    Bitmap bmp;
    Bitmap alteredBitmap;

    // Elements
    private Button takePhotoButton;
    private Button trintukasButton;
    private Button autoriusButton;
    private Button colorButton;
    private DrawableImageView photoView;

    // Modules
    private Utility util;
    private ColorPicker cp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        util = new Utility(this);
        cp = new ColorPicker(MainActivity.this, 255, 255, 255);
        setContentView(R.layout.activity_main);
        setup();
    }

    private void setup() {
        setupResources();
        setupButtons();
    }

    private void setupResources() {
        takePhotoButton = findViewById(R.id.take_photo_button);
        trintukasButton = findViewById(R.id.trintukas_button);
        autoriusButton = findViewById(R.id.autorius_button);
        colorButton = findViewById(R.id.color_button);
        photoView = findViewById(R.id.photo_view);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE)
        {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            }
            else
            {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        super.onActivityResult(requestCode, resultCode, intent);

        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK)
        {
            bmp = (Bitmap) intent.getExtras().get("data");

            alteredBitmap = Bitmap.createBitmap(bmp.getWidth(), bmp
                    .getHeight(), bmp.getConfig());

            photoView.setNewImage(alteredBitmap, bmp);
            togglePhotoView(true);
        }
    }

    private void togglePhotoView(boolean state) {
        if (state == true) {
            takePhotoButton.setVisibility(View.INVISIBLE);
            photoView.setVisibility(View.VISIBLE);
        } else {
            takePhotoButton.setVisibility(View.VISIBLE);
            photoView.setVisibility(View.INVISIBLE);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void takePhoto() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
        } else {
            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, CAMERA_REQUEST);
        }
    }

    private void setupButtons() {
        takePhotoButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            public void onClick(View v) {
                takePhoto();
            }
        });

        trintukasButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            public void onClick(View v) {
                if (photoView.drawOn == false) {
                    photoView.setDrawState(true);
                    trintukasButton.setAlpha(1);
                } else {
                    photoView.setDrawState(false);
                    trintukasButton.setAlpha(0.4F);
                }

            }
        });

        colorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cp.show();
            }
        });

        cp.setCallback(new ColorPickerCallback() {
           @Override
           public void onColorChosen(@ColorInt int color) {
               photoView.setColor(color);
               colorButton.setBackgroundColor(color);
               cp.dismiss();
           }
        });
    }
}
