package com.example.treciauzduotis;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.pes.androidmaterialcolorpickerdialog.ColorPicker;
import com.pes.androidmaterialcolorpickerdialog.ColorPickerCallback;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int CAMERA_REQUEST = 1888;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    public static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;
    Bitmap bmp;
    Bitmap alteredBitmap;
    public ListView mList;

    // Elements
    private Button takePhotoButton;
    private Button trintukasButton;
    private Button autoriusButton;
    private Button colorButton;
    private Button voiceButton;
    private ImageView colorView;
    private DrawableImageView photoView;
    private DrawableImageView authorView;

    // Modules
    private Utility util;
    private ColorPicker cp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        util = new Utility(this);
        cp = new ColorPicker(MainActivity.this, 255, 255, 255);
        setContentView(R.layout.activity_main);
        setup();
    }

    private void setup() {
        setupResources();
        setupButtons();
    }

    public void startVoiceRecognitionActivity() {
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speech recognition demo");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "lt");
            startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
        } catch(ActivityNotFoundException e) {
            String appPackageName = "com.google.android.googlequicksearchbox";
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
            } catch (android.content.ActivityNotFoundException anfe) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
            }
        }
    }

    private void setupResources() {
        takePhotoButton = findViewById(R.id.take_photo_button);
        trintukasButton = findViewById(R.id.trintukas_button);
        autoriusButton = findViewById(R.id.autorius_button);
        colorButton = findViewById(R.id.color_button);
        voiceButton = findViewById(R.id.voice_button);
        photoView = findViewById(R.id.photo_view);
        authorView = findViewById(R.id.author_view);
        colorView = findViewById(R.id.color_view);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_CAMERA_PERMISSION_CODE)
        {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        super.onActivityResult(requestCode, resultCode, intent);

        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK)
        {
            bmp = (Bitmap) intent.getExtras().get("data");

            alteredBitmap = Bitmap.createBitmap(bmp.getWidth(), bmp
                    .getHeight(), bmp.getConfig());

            Bitmap alteredBitmap2 = Bitmap.createBitmap(bmp.getWidth(), bmp
                    .getHeight(), bmp.getConfig());

            photoView.setNewImage(alteredBitmap, bmp);
            authorView.setNewImage(alteredBitmap2, alteredBitmap2);
            togglePhotoView(true);
        } else if (requestCode == VOICE_RECOGNITION_REQUEST_CODE && resultCode == RESULT_OK) {
            // Fill the list view with the strings the recognizer thought it
            // could have heard
            ArrayList matches = intent.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            // matches is the result of voice input. It is a list of what the
            // user possibly said.
            // Using an if statement for the keyword you want to use allows the
            // use of any activity if keywords match
            // it is possible to set up multiple keywords to use the same
            // activity so more than one word will allow the user
            // to use the activity (makes it so the user doesn't have to
            // memorize words from a list)
            // to use an activity from the voice input information simply use
            // the following format;
            // if (matches.contains("keyword here") { startActivity(new
            // Intent("name.of.manifest.ACTIVITY")

            if (matches.contains("autorius") || matches.contains("justinas") || matches.contains("Justinas")) {
                if (authorView.authorVisible == false) {
                    authorView.drawAuthor();
                    autoriusButton.setAlpha(1);
                } else {
                    authorView.clean();
                    autoriusButton.setAlpha(0.4F);
                }
            } else if (matches.contains("trintukas")) {
                if (photoView.drawOn == false) {
                    photoView.setDrawState(true);
                    trintukasButton.setAlpha(1);
                } else {
                    photoView.setDrawState(false);
                    trintukasButton.setAlpha(0.4F);
                }
            } else if (matches.contains("spalva")) {
                cp.show();
            }
        }
    }

    private void togglePhotoView(boolean state) {
        if (state == true) {
            takePhotoButton.setVisibility(View.INVISIBLE);
            photoView.setVisibility(View.VISIBLE);
            authorView.setVisibility(View.VISIBLE);
        } else {
            takePhotoButton.setVisibility(View.VISIBLE);
            authorView.setVisibility(View.INVISIBLE);
            photoView.setVisibility(View.INVISIBLE);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void takePhoto() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
        } else {
            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, CAMERA_REQUEST);
        }
    }

    private void setupButtons() {
        takePhotoButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            public void onClick(View v) {
                takePhoto();
            }
        });

        trintukasButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            public void onClick(View v) {
                if (photoView.drawOn == false) {
                    photoView.setDrawState(true);
                    trintukasButton.setAlpha(1);
                } else {
                    photoView.setDrawState(false);
                    trintukasButton.setAlpha(0.4F);
                }

            }
        });

        colorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cp.show();
            }
        });

        colorView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cp.show();
            }
        });

        autoriusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (authorView.authorVisible == false) {
                    authorView.drawAuthor();
                    autoriusButton.setAlpha(1);
                } else {
                    authorView.clean();
                    autoriusButton.setAlpha(0.4F);
                }
            }
        });

        voiceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startVoiceRecognitionActivity();
            }
        });

        cp.setCallback(new ColorPickerCallback() {
           @RequiresApi(api = Build.VERSION_CODES.O)
           @Override
           public void onColorChosen(@ColorInt int color) {
               photoView.setColor(color);
               colorView.setBackgroundColor(color);
               cp.dismiss();
           }
        });
    }
}
