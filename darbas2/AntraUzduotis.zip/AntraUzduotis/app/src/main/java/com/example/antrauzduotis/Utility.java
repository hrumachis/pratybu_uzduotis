package com.example.antrauzduotis;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

import java.util.concurrent.Callable;

public class Utility {
    final Handler handler = new Handler();
    private Activity activity;

    public Utility(Activity activity) {
        this.activity = activity;

        setup();
    }

    private void setup() {
        // Set fullscreen
        activity.requestWindowFeature(Window.FEATURE_NO_TITLE);
        activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    // ---------------------------- Go ---------------------------- //
    public void go(Class where) {
        Intent myIntent = new Intent(activity, where);
        activity.startActivity(myIntent);
    }

    public void go(Class where, boolean finish) {
        Intent myIntent = new Intent(activity, where);
        activity.startActivity(myIntent);

        if (finish == true) {
            activity.finish();
        }
    }

    // ---------------------------- SetTimeout ---------------------------- //
    public void setTimeout(int miliseconds, final Callable<Void> callback) {
        handler.postDelayed(new Runnable() {
            public void run() {
                try {
                    callback.call();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, miliseconds);
    }
}
