package com.example.antrauzduotis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.concurrent.Callable;

import static android.widget.Toast.LENGTH_LONG;

public class MainActivity extends AppCompatActivity {
    // States
    private boolean clearedData = false;
    private boolean animatingWebView = false;

    // Elements
    private Button delfiButton;
    private Button min15Button;
    private Button pabegimasButton;
    private Button isvalytiButton;
    private Button clickMeButton;
    private RelativeLayout clickMeLayout;
    private WebView webView;

    // Modules
    private Utility util;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        util = new Utility(this);
        setContentView(R.layout.activity_main);
        setup();
    }

    @Override
    protected void onStop() {
        setRSSURL();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        setRSSURL();
        super.onDestroy();
    }

    private void setup() {
        setupResources();
        setupButtons();
        setupWebView();
    }

    private boolean setRSSURL() {
        if (clearedData == true) {
            return false;
        }

        SharedPreferences pref = getApplicationContext().getSharedPreferences("storage418", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("RSSURL", webView.getUrl());
        editor.apply();

        return true;
    }

    private void clearRSSURL() {
        SharedPreferences pref = getApplicationContext().getSharedPreferences("storage418", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("RSSURL", "");
        editor.apply();
        clearedData = true;
    }

    private String getRSSURL() {
        SharedPreferences prefs = getSharedPreferences("storage418", MODE_PRIVATE);
        return prefs.getString("RSSURL", "");
    }

    private void setupWebView() {
        String RSSURL = getRSSURL();
        String html;
        webView.setWebViewClient(new WebViewClient());

        if (RSSURL == "") {
            html = "<html><head></head><body>Justinas Mejeris Mkdf-16/1</body></html>";
            webView.loadDataWithBaseURL("", html, "text/html", "utf-8", "");
        } else {
            webView.loadUrl(RSSURL);
        }
    }

    private void setupResources() {
        webView = findViewById(R.id.webView);
        delfiButton = findViewById(R.id.delfi_button);
        min15Button = findViewById(R.id.min15_button);
        pabegimasButton = findViewById(R.id.pabegimas_button);
        isvalytiButton = findViewById(R.id.isvalyti_button);
        clickMeButton = findViewById(R.id.press_me);
        clickMeLayout = findViewById(R.id.press_me_layout);
    }

    private void pabegimasAnimation() {
        final Animation animation = new TranslateAnimation(0,1000,0,0);
        animation.setDuration(800);
        animation.setFillAfter(true);
        pabegimasButton.startAnimation(animation);
    }

    private void fadeInWebView() {
        Animation fadeIn = new AlphaAnimation(0, 1);
        fadeIn.setInterpolator(new DecelerateInterpolator());
        fadeIn.setDuration(700);

        AnimationSet animation = new AnimationSet(false);
        animation.addAnimation(fadeIn);
        animation.setFillAfter(true);

        webView.startAnimation(animation);
        animatingWebView = false;
    }

    private void fadeOutWebView() {
        Animation fadeOut = new AlphaAnimation(1, 0);
        fadeOut.setInterpolator(new AccelerateInterpolator());
        fadeOut.setDuration(700);

        AnimationSet animation = new AnimationSet(false); //change to false
        animation.addAnimation(fadeOut);
        animation.setFillAfter(true);

        webView.startAnimation(animation);
    }

    private void toggleWebView() {
        if (animatingWebView == false) {
            animatingWebView = true;

            fadeOutWebView();

            final Animation animation = new TranslateAnimation(0,-1500,0,0);
            animation.setDuration(600);
            animation.setFillAfter(true);
            webView.startAnimation(animation);

            util.setTimeout(700, new Callable<Void>() {
                public Void call() throws Exception {
                    fadeInWebView();

                    final Animation animation = new TranslateAnimation(1500,0,0,0);
                    animation.setDuration(600);
                    animation.setFillAfter(true);
                    webView.startAnimation(animation);


                    return null;
                }
            });
        }
    }

    private void clickMeApear() {
        clickMeLayout.setVisibility(View.VISIBLE);
    }

    private void clickMe() {
        fadeInWebView();
        clickMeLayout.setVisibility(View.INVISIBLE);
        final Animation animation = new TranslateAnimation(1000,0,0,0);
        animation.setDuration(800);
        animation.setFillAfter(true);
        pabegimasButton.startAnimation(animation);
    }

    private void setupButtons() {
        delfiButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                webView.loadUrl("http://www.delfi.lt");
                toggleWebView();
            }
        });

        min15Button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                webView.loadUrl("http://www.15min.lt");
                toggleWebView();
            }
        });

        pabegimasButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                fadeOutWebView();
                pabegimasAnimation();
                clickMeApear();
            }
        });

        isvalytiButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                clearRSSURL();
                Toast toast = Toast.makeText(getApplicationContext(), "Atmintis isvalyta", Toast.LENGTH_SHORT);
                toast.show();
            }
        });

        clickMeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                clickMe();
            }
        });
    }
}
