package com.example.pirmauzduotis;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class StrategyActivity extends AppCompatActivity {
    // Modules
    private Utility util;

    // Elements
    private ImageButton homeButton;
    private ImageButton infoButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        util = new Utility(this);
        setContentView(R.layout.activity_strategy);
        setup();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    private void setup() {
        setupResources();
        setupButtons();
    }

    private void setupResources() {
        homeButton = findViewById(R.id.button_home);
        infoButton = findViewById(R.id.button_info);
    }

    private void setupButtons() {
        homeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                util.go(MainActivity.class, true);
            }
        });

        infoButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                util.go(InfoActivity.class, true);
            }
        });
    }
}
