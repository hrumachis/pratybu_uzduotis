package com.example.pirmauzduotis;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class InfoActivity extends AppCompatActivity {
    // Math values
    private int lpBasePoints = 0;
    private int lpIncPoints = 0;

    // Modules
    private Utility util;

    // Elements
    private ImageButton homeButton;
    private ImageButton strategyButton;
    private Button submitButton;
    private RadioButton decreaseButton;
    private CheckBox clearFieldsCheckBox;
    private TextView lpCounterView;
    private EditText lpBasePointsEditText;
    private EditText lpIncPointsEditText;
    private ConstraintLayout viewLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        util = new Utility(this);
        setContentView(R.layout.activity_info);
        setup();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    private void setup() {
        setupResources();
        setupButtons();
        setLpCounter(0);
    }

    private void submitButtot() {
        int lpBasePoints = getLpBasePoints();
        int lpIncPoints = getLpIncPoints();

        if (decreaseButton.isChecked()) {
            decreaseLpPoints(lpBasePoints, lpIncPoints);
        } else {
            increaseLpPoints(lpBasePoints, lpIncPoints);
        }

        if (clearFieldsCheckBox.isChecked()) {
            clearFields();
        }

        if (lpBasePoints > 10) {
            viewLayout.setBackground(getResources().getDrawable(R.drawable.bg_gradient_field1_0));
        }

        if (lpBasePoints > 20) {
            viewLayout.setBackground(getResources().getDrawable(R.drawable.bg_gradient_field1_1));
        }

        if (lpBasePoints > 50) {
            viewLayout.setBackground(getResources().getDrawable(R.drawable.bg_gradient_field1_2));
        }

        if (lpBasePoints > 100) {
            viewLayout.setBackground(getResources().getDrawable(R.drawable.bg_gradient_field1_3));
        }
    }

    private void increaseLpPoints(int basePoints, int incPoints) {
        setLpCounter(basePoints + incPoints);
    }

    private void decreaseLpPoints(int basePoints, int incPoints) {
        setLpCounter(basePoints - incPoints);
    }

    private int getLpBasePoints() {
        return Integer.parseInt(lpBasePointsEditText.getText().toString());
    }

    private int getLpIncPoints() {
        return Integer.parseInt(lpIncPointsEditText.getText().toString());
    }

    private void clearFields() {
        lpBasePointsEditText.setText("");
        lpIncPointsEditText.setText("");
    }

    private void setLpCounter(int count) {
        lpCounterView.setText(Integer.toString(count));
    }

    private void setupResources() {
        homeButton = findViewById(R.id.button_home);
        strategyButton = findViewById(R.id.button_strategy);
        submitButton = findViewById(R.id.button_submit);
        lpCounterView = findViewById(R.id.lp_counter);
        lpBasePointsEditText = findViewById(R.id.lp_points_base);
        lpIncPointsEditText = findViewById(R.id.lp_inc_points);
        viewLayout = findViewById(R.id.view_layout);
        decreaseButton = findViewById(R.id.radioButton_decrease);
        clearFieldsCheckBox = findViewById(R.id.checkBox_clear_fields);
    }

    private void setupButtons() {
        strategyButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                util.go(StrategyActivity.class, true);
            }
        });

        homeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                util.go(MainActivity.class, true);
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                submitButtot();
            }
        });
    }
}
