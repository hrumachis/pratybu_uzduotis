package com.example.pirmauzduotis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // Modules
    private Utility util;

    // Elements
    private ImageButton strategyButton;
    private ImageButton infoButton;
    private Button button_rate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        util = new Utility(this);
        setContentView(R.layout.activity_main);
        setup();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    private void setup() {
        setupResources();
        setupButtons();
    }

    private void rate() {
        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, "Thanks for rating!", Toast.LENGTH_SHORT);
        toast.show();
    }

    private void setupResources() {
        strategyButton = findViewById(R.id.button_strategy);
        infoButton = findViewById(R.id.button_info);
        button_rate = findViewById(R.id.button_rate);
    }

    private void setupButtons() {
        strategyButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                util.go(StrategyActivity.class, true);
            }
        });

        infoButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                util.go(InfoActivity.class, true);
            }
        });

        button_rate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                rate();
            }
        });
    }
}
